<?php

//exit("SCRIPT DE NOTICIAS DESATIVADO");

require_once(__DIR__ . '/utils/NucleoRequests.php');
require_once(__DIR__ . '/ng_configs.php');

/**
 *  INICIO DO SCRIPT
 */
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$timezone = new DateTimeZone('America/Sao_Paulo');

$TYPE_IMPORT = 'noticias';

$LOCAL_LOG = LOG_DIR . 'import-' . CITY_IMPORT . '-' . $TYPE_IMPORT . '.log';

file_put_contents($LOCAL_LOG, '');

$MIDIAS_LOCAL = MIDIAS . $TYPE_IMPORT . DIRECTORY_SEPARATOR;

$json_data = file_get_contents(JSON_DIR . $TYPE_IMPORT .'.json');

$result = json_decode($json_data, true);
$count = 0;
$new_post = [];
$datetime = '';

if (!empty($result)) {

    $datetime = new DateTime('now', $timezone);

    file_put_contents($LOCAL_LOG, 'A miração será feita para a URL ' . REQUEST_URL . "\n" .
        'Migração iniciada as ' . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'As midias serão salvas no diretório: [ ' . $MIDIAS_LOCAL . ' ]' . "\n"
        . "\n" . PHP_EOL, FILE_APPEND | LOCK_EX);

    foreach ($result as $item) {
        if (!empty($item['id']) && !empty($item['image']) && !file_exists($MIDIAS_LOCAL . $item['id'] . '.jpg')) {
            file_put_contents($MIDIAS_LOCAL . $item['id'] . '.jpg', base64_decode($item['image']));
        }

        $content = '';

        if (!empty($item['text'])) {
            $content = strip_tags($item['text'], '<table><tbody><thead><tfooter><tr><th><td><iframe><a><ul><li><ol><br><u><b><i><img>');
        }

        $date = new DateTime('now', $timezone);

        if (!empty($item['creation_date'])) {
            $data_obj = new DateTime($item['creation_date']);
            $date = $data_obj->format("Y-m-d H:i:s");
        }

        $new_post = [
            'post_type' => 'post',
            'post_content' => $content,
            'post_title' => $item['title'],
            'post_date' => $date,
        ];

        if (!empty($item['description'])) {
            $new_post['post_excerpt'] = $item['description'];
        }

        $new_post['categories'][] = [
            'cat_name' => 'Notícias',
            'taxonomy' => 'category'
        ];

        if (!empty($item['id']) && file_exists($MIDIAS_LOCAL . $item['id'] . '.jpg')) {
            $new_post['thumb'] = $MIDIAS_LOCAL . $item['id'] . '.jpg';
        }

        echo 'Enviando: ' . $item['id'] . ' <br>';
        echo "<pre>";
        print_r($new_post);
        echo "<pre>";
        $count++;
//        exit("SCRIPT DE NOTICIAS DESATIVADO");
        // Iniciamos a função do CURL:
        $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);

        $datetime = new DateTime('now', $timezone);
        file_put_contents($LOCAL_LOG, '['. $datetime->format('Y-m-d H:i:s') . ']'.'Sucesso: O post com ID: (' . $item['id'] . ") foi adicionado." ."\n" . PHP_EOL, FILE_APPEND | LOCK_EX);

    }

    $datetime = new DateTime('now', $timezone);
    file_put_contents($LOCAL_LOG,
        "\n" . 'Migração finalizada as: ' . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'Total de posts migrados: ' . $count
        . PHP_EOL, FILE_APPEND | LOCK_EX);

} else {

    $datetime = new DateTime('now', $timezone);
    file_put_contents($LOCAL_LOG,
        'Não existem dados para migração'
        . "\n" . "Horário da execução: " . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'Total de posts migrados: ' . $count
        . PHP_EOL, FILE_APPEND | LOCK_EX);

}

echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=galerias.php'>";
