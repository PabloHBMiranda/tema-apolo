<?php

exit("SCRIPT DE BANNERS DESATIVADO");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use function Sodium\randombytes_buf;

require_once(__DIR__ . '/ng_configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');

$conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => false,
));

$stmt = $conOrigem->prepare("SELECT
	g.id,
	g.nome as titulo,
	g.formatos,
	g.protecao,
	g.max_img,
	g.capa,
	u.midia_id,
	u.descricao as texto,
	u.pos_x,
	u.pos_y,
	u.pos_w,
	u.pos_h,
	( SELECT m.midia FROM midias m WHERE m.id = u.midia_id ) AS thumb 
FROM
	galerias g
	LEFT JOIN midias_uso u ON g.capa = u.id 
WHERE
	g.protecao = 1 && g.formatos = 'img' && g.id = 4
ORDER BY
	id DESC");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$new_post = [];
$cont_falta = 0;
echo "<pre>";

function getGaleria($id_galeria) {
    $conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => false,
    ));

    $stmt = $conOrigem->prepare("SELECT
	m.* 
FROM
	midias_uso mu
	
LEFT JOIN midias m on m.id = mu.midia_id
WHERE
	galeria_id = {$id_galeria}");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


foreach ($result as $item) {

    if (file_exists(MIDIAS . $item['thumb'])) {
        $new_post['meta_input'] = [
            'miniatura' => MIDIAS . $item['thumb'],
            '_miniatura' => 'field_5b5ec69578a1c'
        ];
    }

    $galeria = getGaleria($item['id']);

    if (count($galeria) > 0) {
        foreach ($galeria as $banner) {

            if (!empty($banner['midia']) && file_exists(MIDIAS . $banner['midia'])) {

                $new_post = [
                    'post_type' => 'banners',
                    'post_content' => '',
                    'post_title' => $banner['titulo'],
                    'post_date' => $banner['data']
                ];

                $posts_meta = [
                    '_imagem' => 'field_5eb98a67f9e7d',
                    'imagem' => MIDIAS . $banner['midia']
                ];

                $new_post['meta_input'] = $posts_meta;

                // Iniciamos a função do CURL:
                $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);
                print_r(json_decode($res));
                echo "<br>";
                echo "<br>";
                echo "<br>";
            }
        }
    }
}
