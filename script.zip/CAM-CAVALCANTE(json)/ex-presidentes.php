<?php

exit("SCRIPT DE EX-PRESIDENTES ENCERRADOS");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use function Sodium\randombytes_buf;

require_once(__DIR__ . '/utils/configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');
require_once(__DIR__ . '/ng_configs.php');

$conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => false,
));

$stmt = $conOrigem->prepare("SELECT cd8ah_content.title as title, cd8ah_content.introtext, cd8ah_content.created
FROM cd8ah_content
WHERE title = 'Galeria de ex-presidentes'");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$new_post = [];
$cont_falta = 0;
echo "<pre>";

function getGaleria($id_noticia)
{
    $conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => false,
    ));

    $stmt = $conOrigem->prepare("SELECT
	mu.*,
	m.midia 
FROM
	paginas n 
	LEFT JOIN midias_uso mu ON n.galeria = mu.galeria_id
	LEFT JOIN midias m ON m.id = mu.midia_id 
WHERE
	n.id = {$id_noticia}");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

foreach ($result as $item) {

    $content = strip_tags($item['introtext'], '<table><tbody><thead><tfooter><img><tr><th><td><iframe><a><ul><li><ol><p><br><u><b><i>');

    $new_post = [
        'post_type' => 'page',
        'post_content' => $content,
        'post_title' => $item['title']
    ];

    // Imagem no texto
    $imagens = [];
    preg_match_all('/src="(.*?)"/is', $item['introtext'], $imagens, PREG_SET_ORDER);
    if (count($imagens) > 0) {
        foreach ($imagens as $match) {
            if (isset($match[1]) && strstr($match[1], 'images/ex-presidentes/')) {
                $anexo = trim(basename($match[1]));
                if (file_exists(EX_PRESIDENTES . $anexo)) {
                    $new_post['imagem_texto'][] = [
                        'novo' => EX_PRESIDENTES . $anexo,
                        'antigo' => trim($match[1])
                    ];
                }
            }
        }
    }

    echo "<pre>";
    print_r($new_post);
    echo "<pre>";
//    exit();

    // Iniciamos a função do CURL:
    $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);
    print_r(json_decode($res));
    echo "<br>";
    echo "<br>";
    echo "<br>";
}

echo '<p>Não há mais dados para migração.</p>';
echo "<br>";
echo "<br>";
