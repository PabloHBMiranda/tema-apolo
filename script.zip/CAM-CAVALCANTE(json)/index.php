<html>
<body>
<h4>ADM -> NUCLEOWEB</h4>
<fieldset>
    <a href="noticias.php"><button>NOTÍCIAS</button></a>
    <a href="paginas.php"><button>PÁGINAS</button></a>
    <a href="galerias.php"><button>GALERIAS</button></a>
    <a href="videos.php"><button>VÍDEOS</button></a>
    <a href="popups.php"><button>POPUPS</button></a>
    <a href="banners.php"><button>BANNERS</button></a>
    <a href="sessoes.php"><button>SESSÕES</button></a>
    <a href="ex-presidentes.php"><button>EX PRESIDENTES</button></a>
</fieldset>
</body>
</html>
