<?php
// LOCAL ONDE ESTÁ OS ARQUIVOS
define('MIDIAS', __DIR__ . DIRECTORY_SEPARATOR . 'midias' . DIRECTORY_SEPARATOR);
define('THUMB', __DIR__ . DIRECTORY_SEPARATOR . 'midias' . DIRECTORY_SEPARATOR . 'items' . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR);
define('GALERIA', __DIR__ . DIRECTORY_SEPARATOR . 'midias' . DIRECTORY_SEPARATOR . 'galleries' . DIRECTORY_SEPARATOR);
define('EX_PRESIDENTES', __DIR__ . DIRECTORY_SEPARATOR . 'midias' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'ex-presidentes' . DIRECTORY_SEPARATOR);

// BANCO DE DADOS ANTIGO
define('DB_NAME', 'mairipotaba_antigo');
define('DB_HOST', 'mariadb');
define('DB_USER', 'root');
define('DB_PASS', '');

// URL SITE ANTIGO (usado para arquivos no texto)
define('OLD_URL', 'www.cavalcante.go.leg.br');

// URL QUE ESTÁ O NG MIGRATE QUE IRÁ RECEBER OS DADOS
define('REQUEST_URL', "http://localhost/cam-cavalcante-novo/public/");

// NOME DA CIDADE PARA INFORMAR NO LOG
define('CITY_IMPORT', 'cam-cavalcante');
// LOCAL DOS LOGS
define('LOG_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'migration-import' . DIRECTORY_SEPARATOR . 'log' . DIRECTORY_SEPARATOR);


// LOCAL DOS JSON
define('JSON_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'migration-import' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR);