<?php

exit("SCRIPT DE VIDEOS DESATIVADO");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use function Sodium\randombytes_buf;

require_once(__DIR__ . '/utils/configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');
require_once(__DIR__ . '/ng_configs.php');

$conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => false,
));

$stmt = $conOrigem->prepare("SELECT
	g.id,
	g.nome as titulo,
	g.formatos,
	g.protecao,
	g.max_img,
	g.capa,
	u.midia_id,
	u.descricao as texto,
	u.pos_x,
	u.pos_y,
	u.pos_w,
	u.pos_h,
	( SELECT m.midia FROM midias m WHERE m.id = u.midia_id ) AS thumb 
FROM
	galerias g
	LEFT JOIN midias_uso u ON g.capa = u.id 
WHERE
	g.protecao = 0 && g.formatos LIKE '%video%'
ORDER BY
	id DESC");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$new_post = [];
$cont_falta = 0;
echo "<pre>";

function getGaleria($id_galeria) {
    $conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => false,
    ));

    $stmt = $conOrigem->prepare("SELECT
	m.* 
FROM
	midias_uso mu
	
LEFT JOIN midias m on m.id = mu.midia_id
WHERE
	galeria_id = {$id_galeria}");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

foreach ($result as $item) {
    $galeria = getGaleria($item['id']);

    if (count($galeria) > 0) {
        foreach ($galeria as $gal) {
            $new_post = [
                'post_type' => 'videos',
                'post_content' => '',
                'post_title' => $gal['titulo'],
                'post_date' => $gal['data']
            ];

            $imagem = __DIR__ . DIRECTORY_SEPARATOR . 'tmp_videos' . DIRECTORY_SEPARATOR . md5($gal['midia']) . '.jpg';

            @copy($gal['imagem'], $imagem);

            $new_post['meta_input'] = [
                '_youtube' => 'field_5b5d8d7fcaf5c',
                'youtube' => $gal['midia'],
                'miniatura' => $imagem,
                '_miniatura' => 'field_5b5d8d98caf5d'
            ];

            // Iniciamos a função do CURL:
            $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);
            print_r(json_decode($res));
            echo "<br>";
            echo "<br>";
            echo "<br>";
        }
    }
}
