<?php

//exit("SCRIPT DAS GALERIAS FECHADO ANTES DA EXECUÇÃO");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . '/ng_configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');
$timezone = new DateTimeZone('America/Sao_Paulo');

$TYPE_IMPORT = 'galerias';

$LOCAL_LOG = LOG_DIR . 'import-' . CITY_IMPORT . '-' . $TYPE_IMPORT . '.log';

file_put_contents($LOCAL_LOG, '');

$MIDIAS_LOCAL = MIDIAS . $TYPE_IMPORT . DIRECTORY_SEPARATOR;

$json_data = file_get_contents(JSON_DIR . $TYPE_IMPORT . '.json');

$result = json_decode($json_data, true);
$count = 0;
$datetime = '';

if ($result) {

    $datetime = new DateTime('now', $timezone);

    file_put_contents($LOCAL_LOG, 'A miração será feita para a URL ' . REQUEST_URL . "\n" .
        'Migração iniciada as ' . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'As midias serão salvas no diretório: [ ' . $MIDIAS_LOCAL . ' ]' . "\n"
        . "\n" . PHP_EOL, FILE_APPEND | LOCK_EX);

    foreach ($result as $item) {
        if (!isset($item['b_size'])) {
            $new_post = [];
            $galeria = [];

            $content = '';

            $date = new DateTime('now', $timezone);

            if (!empty($item['creation_date'])) {
                $data_obj = new DateTime($item['creation_date']);
                $date = $data_obj->format("Y-m-d H:i:s");
            };

            $new_post = [
                'post_type' => 'galerias',
                'post_content' => $content,
                'post_title' => $item['title'] ?? '',
                'post_date' => $date,
            ];

            $new_post['meta_galeria'] = [
                'field_name' => 'images',
                '_images' => 'field_5ffdc65427df8'
            ];

            if (isset($item['children'])) {
                foreach ($item['children'] as $children) {
                    if(isset($children['image']) && isset($children['id'])){
                        $galeria[] = [
                            'id' => $children['id'],
                            'image' => $children['image'],
                        ];
                    }
                }
            } else {
                if(isset($item['image']) && isset($item['id'])) {
                    $galeria[] = [
                        'id' => $item['id'],
                        'image' => $item['image'],
                    ];
                }
            }

            $new_post['thumb'] = '';

            foreach ($galeria as $index => $galeria_item){

                if (isset($galeria_item['id']) && !empty($galeria_item['id'])
                    && !empty($galeria_item['image']) && isset($galeria_item['image'])
                    && !file_exists($MIDIAS_LOCAL . $galeria_item['id'] . '.jpg')) {
                    file_put_contents($MIDIAS_LOCAL . $galeria_item['id'] . '.jpg', base64_decode($galeria_item['image']));
                }

                if (file_exists($MIDIAS_LOCAL . $galeria_item['id'] . '.jpg')) {
                    $new_post['meta_galeria']['midias'][] = $MIDIAS_LOCAL . $galeria_item['id'] . '.jpg';

                    if($index === 0){
                        $new_post['thumb'] = $MIDIAS_LOCAL . $galeria_item['id'] . '.jpg';
                    }
                }
            }

            echo "<pre>";
            print_r($new_post);
            echo "</pre>";

            echo 'Enviando: ' . $item['id'] . ' <br>';

            // Iniciamos a função do CURL:
            $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);

            $count++;
            $datetime = new DateTime('now', $timezone);
            file_put_contents($LOCAL_LOG, '['. $datetime->format('Y-m-d H:i:s') . ']'.'Sucesso: O post com ID: (' . $item['id'] . ") foi adicionado." ."\n" . PHP_EOL, FILE_APPEND | LOCK_EX);

        }
    }

    $datetime = new DateTime('now', $timezone);
    file_put_contents($LOCAL_LOG,
        "\n" . 'Migração finalizada as: ' . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'Total de posts migrados: ' . $count
        . PHP_EOL, FILE_APPEND | LOCK_EX);

} else {

    $datetime = new DateTime('now', $timezone);
    file_put_contents($LOCAL_LOG,
        'Não existem dados para migração'
        . "\n" . "Horário da execução: " . $datetime->format('Y-m-d H:i:s')
        . "\n" . 'Total de posts migrados: ' . $count
        . PHP_EOL, FILE_APPEND | LOCK_EX);

}
