<?php

exit("SCRIPT DE PÁGINAS DESATIVADO");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use function Sodium\randombytes_buf;

require_once(__DIR__ . '/utils/configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');
require_once(__DIR__ . '/ng_configs.php');

$conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => false,
));

$stmt = $conOrigem->prepare("SELECT
	n.*,
	m.midia as thumb
FROM
	paginas n
	LEFT JOIN midias_uso mu ON n.capa = mu.id
	LEFT JOIN midias m ON m.id = mu.midia_id 
WHERE
	oculto = 0");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$new_post = [];
$cont_falta = 0;
echo "<pre>";

function getGaleria($id_noticia) {
    $conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => false,
    ));

    $stmt = $conOrigem->prepare("SELECT
	mu.*,
	m.midia 
FROM
	paginas n 
	LEFT JOIN midias_uso mu ON n.galeria = mu.galeria_id
	LEFT JOIN midias m ON m.id = mu.midia_id 
WHERE
	n.id = {$id_noticia}");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

foreach ($result as $item) {
    $content = strip_tags($item['texto'], '<table><tbody><thead><tfooter><img><tr><th><td><iframe><a><ul><li><ol><p><br><u><b><i>');

    $new_post = [
        'post_type' => 'page',
        'post_content' => $content,
        'post_title' => $item['titulo']
    ];

    if (!empty( $item['thumb']) && file_exists(MIDIAS . $item['thumb'])) {
        $new_post['thumb'] = MIDIAS . $item['thumb'];
    }

    $galeria = getGaleria($item['id']);

    if (count($galeria) > 0) {
        foreach ($galeria as $id => $value) {
            if (file_exists(MIDIAS . $value['midia']) && !empty($value['midia'])) {
                $new_post['galeria'][] = MIDIAS . $value['midia'];
            }
        }
    }

    if (!empty($item['cat_nome'])) {
        $new_post['categories'][] = [
            'cat_name' => $item['cat_nome'],
            'taxonomy' => 'category'
        ];
    }

    // Imagem no texto
    $imagens = [];
    preg_match_all('/src="(.*?)"/is', $item['texto'], $imagens, PREG_SET_ORDER);
    if (count($imagens) > 0) {
        foreach ($imagens as $match) {
            if (isset($match[1]) && strstr($match[1], 'res/midias/img')) {
                $anexo = trim(basename($match[1]));
                if (file_exists(MIDIAS . $anexo)) {
                    $new_post['imagem_texto'][] = [
                        'novo' => MIDIAS . $anexo,
                        'antigo' => trim($match[1])
                    ];
                }
            }
        }
    }

    // Arquivos no texto
    $arquivos = [];
    preg_match_all('/href="(.*?)"/is', $content, $arquivos, PREG_SET_ORDER);
    if (count($arquivos) > 0) {
        foreach ($arquivos as $match) {
            if (isset($match[1]) && strstr($match[1], OLD_URL)) {
                $url = trim($match[1]);
                $ex = explode('/', $url);
                $arquivo = '';
                if (!empty(trim($ex[count($ex) - 1]))) {
                    $arquivo = $ex[count($ex) - 1];
                }
                if ($arquivo != '') {
                    if (file_exists(MIDIAS . $arquivo)) {
                        $new_post['arquivos'][] = [
                            'novo' => MIDIAS . $arquivo,
                            'antigo' => $url
                        ];
                    }
                }
            }
        }
    }

    // Iniciamos a função do CURL:
    $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);
    print_r(json_decode($res));
    echo "<br>";
    echo "<br>";
    echo "<br>";
}
