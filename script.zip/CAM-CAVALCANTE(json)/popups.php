<?php

exit("SCRIPT DE POPUPS DESATIVADO");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use function Sodium\randombytes_buf;

require_once(__DIR__ . '/utils/configs.php');
require_once(__DIR__ . '/utils/NucleoRequests.php');
require_once(__DIR__ . '/ng_configs.php');

$conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => false,
));

$stmt = $conOrigem->prepare("SELECT
	n.*,
	m.midia as thumb
FROM
	popup n
	LEFT JOIN midias_uso mu ON n.capa = mu.id
	LEFT JOIN midias m ON m.id = mu.midia_id 
WHERE
	oculto = 0");
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$new_post = [];
$cont_falta = 0;
echo "<pre>";


function getGaleria($id_noticia) {
    $conOrigem = new PDO("mysql:dbname=" . DB_NAME . ";host=" . DB_HOST, DB_USER, DB_PASS, $options = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => false,
    ));

    $stmt = $conOrigem->prepare("SELECT
	mu.*,
	m.midia 
FROM
	paginas n 
	LEFT JOIN midias_uso mu ON n.galeria = mu.galeria_id
	LEFT JOIN midias m ON m.id = mu.midia_id 
WHERE
	n.id = {$id_noticia}");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

foreach ($result as $item) {

    $new_post = [
        'post_type' => 'popups',
        'post_content' => '',
        'post_title' => $item['titulo']
    ];

    $galeria = getGaleria($item['id']);

    if (count($galeria) > 0) {
        foreach ($galeria as $id => $value) {
            if (file_exists(MIDIAS . $value['midia']) && !empty($value['midia'])) {
                $new_post['galeria'][] = MIDIAS . $value['midia'];
            }
        }
    }

    if (!empty($item['cat_nome'])) {
        $new_post['categories'][] = [
            'cat_name' => $item['cat_nome'],
            'taxonomy' => 'category'
        ];
    }

    $posts_meta = [
        '_imagem' => 'field_5d5da37a8e9e8',
        'imagem' => (!empty($item['thumb'])) ? MIDIAS . $item['thumb'] : '',
        '_link' => 'field_5d5da3fe8e9e9',
        'link' => $item['link'],
        '_target' => 'field_5d5da4158e9ea',
        'target' => ($item['target'] == '_blank') ? true : false,
        '_data_inicio' => 'field_5d5da44c8e9eb',
        'data_inicio' => $item['inicio'],
        '_data_fim' => 'field_5d5da4f08e9ed',
        'data_fim' => $item['fim']
    ];

    $new_post['meta_input'] = $posts_meta;

    // Iniciamos a função do CURL:
    $res = NucleoRequests::send(REQUEST_URL, 1, ['new_post' => json_encode($new_post), 'ng-migrate-posts' => true], false);
    print_r(json_decode($res));
    echo "<br>";
    echo "<br>";
    echo "<br>";
}
